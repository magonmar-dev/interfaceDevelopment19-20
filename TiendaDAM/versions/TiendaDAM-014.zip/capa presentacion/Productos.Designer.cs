﻿namespace capa_presentacion
{
    partial class Productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnResetFilters = new System.Windows.Forms.Button();
            this.cbTipoB = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txbNomB = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panelCamara = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txbObjetivo = new System.Windows.Forms.TextBox();
            this.txbZoom = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txbPantallaCam = new System.Windows.Forms.TextBox();
            this.txbFactor = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txbTipoCam = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txbSensor = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txbResolCam = new System.Windows.Forms.TextBox();
            this.panelMemoria = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txbTipoMem = new System.Windows.Forms.TextBox();
            this.cbTipo = new System.Windows.Forms.ComboBox();
            this.panelTV = new System.Windows.Forms.Panel();
            this.ckbTDT = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txbHD = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txbResolTV = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txbPantallaTV = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txbPanel = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panelObjetivo = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.txbEspeciales = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txbApertura = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txbFocal = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txbMontura = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txbTipoObj = new System.Windows.Forms.TextBox();
            this.txbEspec = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.nudPvp = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txbNombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMod = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panelCamara.SuspendLayout();
            this.panelMemoria.SuspendLayout();
            this.panelTV.SuspendLayout();
            this.panelObjetivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPvp)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnResetFilters);
            this.groupBox2.Controls.Add(this.cbTipoB);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txbNomB);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(93)))), ((int)(((byte)(103)))));
            this.groupBox2.Location = new System.Drawing.Point(20, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(717, 90);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "BUSCAR PRODUCTO";
            // 
            // btnResetFilters
            // 
            this.btnResetFilters.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(31)))), ((int)(((byte)(51)))));
            this.btnResetFilters.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnResetFilters.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetFilters.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnResetFilters.Location = new System.Drawing.Point(606, 22);
            this.btnResetFilters.Name = "btnResetFilters";
            this.btnResetFilters.Size = new System.Drawing.Size(91, 52);
            this.btnResetFilters.TabIndex = 21;
            this.btnResetFilters.Text = "BORRAR FILTROS";
            this.btnResetFilters.UseVisualStyleBackColor = false;
            this.btnResetFilters.Click += new System.EventHandler(this.btnResetFilters_Click);
            // 
            // cbTipoB
            // 
            this.cbTipoB.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbTipoB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTipoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.cbTipoB.FormattingEnabled = true;
            this.cbTipoB.ItemHeight = 18;
            this.cbTipoB.Location = new System.Drawing.Point(423, 36);
            this.cbTipoB.Name = "cbTipoB";
            this.cbTipoB.Size = new System.Drawing.Size(162, 26);
            this.cbTipoB.TabIndex = 2;
            this.cbTipoB.SelectedIndexChanged += new System.EventHandler(this.cbTipoB_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(16, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 20);
            this.label13.TabIndex = 19;
            this.label13.Text = "Nombre";
            // 
            // txbNomB
            // 
            this.txbNomB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbNomB.Location = new System.Drawing.Point(99, 37);
            this.txbNomB.MaxLength = 35;
            this.txbNomB.Name = "txbNomB";
            this.txbNomB.Size = new System.Drawing.Size(162, 24);
            this.txbNomB.TabIndex = 1;
            this.txbNomB.TextChanged += new System.EventHandler(this.txbNomB_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(282, 38);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(124, 20);
            this.label14.TabIndex = 20;
            this.label14.Text = "Tipo de artículo";
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AllowUserToResizeColumns = false;
            this.dataGridView.AllowUserToResizeRows = false;
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView.BackgroundColor = System.Drawing.Color.Black;
            this.dataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView.Location = new System.Drawing.Point(20, 120);
            this.dataGridView.Margin = new System.Windows.Forms.Padding(0);
            this.dataGridView.MultiSelect = false;
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView.RowHeadersWidth = 25;
            this.dataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.Size = new System.Drawing.Size(717, 640);
            this.dataGridView.StandardTab = true;
            this.dataGridView.TabIndex = 0;
            this.dataGridView.Click += new System.EventHandler(this.dataGridView_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panelCamara);
            this.groupBox1.Controls.Add(this.panelMemoria);
            this.groupBox1.Controls.Add(this.cbTipo);
            this.groupBox1.Controls.Add(this.panelTV);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.panelObjetivo);
            this.groupBox1.Controls.Add(this.txbEspec);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cbMarca);
            this.groupBox1.Controls.Add(this.nudPvp);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txbNombre);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(93)))), ((int)(((byte)(103)))));
            this.groupBox1.Location = new System.Drawing.Point(760, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(467, 669);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DATOS DEL PRODUCTO";
            // 
            // panelCamara
            // 
            this.panelCamara.Controls.Add(this.label19);
            this.panelCamara.Controls.Add(this.label25);
            this.panelCamara.Controls.Add(this.txbObjetivo);
            this.panelCamara.Controls.Add(this.txbZoom);
            this.panelCamara.Controls.Add(this.label20);
            this.panelCamara.Controls.Add(this.label24);
            this.panelCamara.Controls.Add(this.txbPantallaCam);
            this.panelCamara.Controls.Add(this.txbFactor);
            this.panelCamara.Controls.Add(this.label21);
            this.panelCamara.Controls.Add(this.txbTipoCam);
            this.panelCamara.Controls.Add(this.label22);
            this.panelCamara.Controls.Add(this.txbSensor);
            this.panelCamara.Controls.Add(this.label23);
            this.panelCamara.Controls.Add(this.txbResolCam);
            this.panelCamara.Location = new System.Drawing.Point(6, 354);
            this.panelCamara.Name = "panelCamara";
            this.panelCamara.Size = new System.Drawing.Size(454, 309);
            this.panelCamara.TabIndex = 44;
            this.panelCamara.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(75, 182);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 20);
            this.label19.TabIndex = 42;
            this.label19.Text = "Objetivo";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(96, 263);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(50, 20);
            this.label25.TabIndex = 46;
            this.label25.Text = "Zoom";
            // 
            // txbObjetivo
            // 
            this.txbObjetivo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbObjetivo.Enabled = false;
            this.txbObjetivo.Location = new System.Drawing.Point(163, 181);
            this.txbObjetivo.MaxLength = 35;
            this.txbObjetivo.Name = "txbObjetivo";
            this.txbObjetivo.Size = new System.Drawing.Size(274, 24);
            this.txbObjetivo.TabIndex = 41;
            // 
            // txbZoom
            // 
            this.txbZoom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbZoom.Enabled = false;
            this.txbZoom.Location = new System.Drawing.Point(163, 262);
            this.txbZoom.MaxLength = 35;
            this.txbZoom.Name = "txbZoom";
            this.txbZoom.Size = new System.Drawing.Size(274, 24);
            this.txbZoom.TabIndex = 45;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(88, 143);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 20);
            this.label20.TabIndex = 40;
            this.label20.Text = "Factor";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(77, 222);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 20);
            this.label24.TabIndex = 44;
            this.label24.Text = "Pantalla";
            // 
            // txbPantallaCam
            // 
            this.txbPantallaCam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbPantallaCam.Enabled = false;
            this.txbPantallaCam.Location = new System.Drawing.Point(163, 221);
            this.txbPantallaCam.MaxLength = 35;
            this.txbPantallaCam.Name = "txbPantallaCam";
            this.txbPantallaCam.Size = new System.Drawing.Size(274, 24);
            this.txbPantallaCam.TabIndex = 43;
            // 
            // txbFactor
            // 
            this.txbFactor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbFactor.Enabled = false;
            this.txbFactor.Location = new System.Drawing.Point(163, 142);
            this.txbFactor.MaxLength = 35;
            this.txbFactor.Name = "txbFactor";
            this.txbFactor.Size = new System.Drawing.Size(274, 24);
            this.txbFactor.TabIndex = 39;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(104, 103);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 20);
            this.label21.TabIndex = 38;
            this.label21.Text = "Tipo";
            // 
            // txbTipoCam
            // 
            this.txbTipoCam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbTipoCam.Enabled = false;
            this.txbTipoCam.Location = new System.Drawing.Point(163, 102);
            this.txbTipoCam.MaxLength = 35;
            this.txbTipoCam.Name = "txbTipoCam";
            this.txbTipoCam.Size = new System.Drawing.Size(274, 24);
            this.txbTipoCam.TabIndex = 37;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(83, 61);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(62, 20);
            this.label22.TabIndex = 36;
            this.label22.Text = "Sensor";
            // 
            // txbSensor
            // 
            this.txbSensor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbSensor.Enabled = false;
            this.txbSensor.Location = new System.Drawing.Point(163, 60);
            this.txbSensor.MaxLength = 35;
            this.txbSensor.Name = "txbSensor";
            this.txbSensor.Size = new System.Drawing.Size(274, 24);
            this.txbSensor.TabIndex = 35;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(53, 19);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(92, 20);
            this.label23.TabIndex = 34;
            this.label23.Text = "Resolución";
            // 
            // txbResolCam
            // 
            this.txbResolCam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbResolCam.Enabled = false;
            this.txbResolCam.Location = new System.Drawing.Point(163, 18);
            this.txbResolCam.MaxLength = 35;
            this.txbResolCam.Name = "txbResolCam";
            this.txbResolCam.Size = new System.Drawing.Size(274, 24);
            this.txbResolCam.TabIndex = 33;
            // 
            // panelMemoria
            // 
            this.panelMemoria.Controls.Add(this.label5);
            this.panelMemoria.Controls.Add(this.txbTipoMem);
            this.panelMemoria.Location = new System.Drawing.Point(5, 350);
            this.panelMemoria.Name = "panelMemoria";
            this.panelMemoria.Size = new System.Drawing.Size(455, 62);
            this.panelMemoria.TabIndex = 32;
            this.panelMemoria.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(105, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 20);
            this.label5.TabIndex = 34;
            this.label5.Text = "Tipo";
            // 
            // txbTipoMem
            // 
            this.txbTipoMem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbTipoMem.Enabled = false;
            this.txbTipoMem.Location = new System.Drawing.Point(163, 19);
            this.txbTipoMem.MaxLength = 35;
            this.txbTipoMem.Name = "txbTipoMem";
            this.txbTipoMem.Size = new System.Drawing.Size(274, 24);
            this.txbTipoMem.TabIndex = 33;
            // 
            // cbTipo
            // 
            this.cbTipo.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTipo.Enabled = false;
            this.cbTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.cbTipo.FormattingEnabled = true;
            this.cbTipo.ItemHeight = 18;
            this.cbTipo.Location = new System.Drawing.Point(169, 329);
            this.cbTipo.Name = "cbTipo";
            this.cbTipo.Size = new System.Drawing.Size(274, 26);
            this.cbTipo.TabIndex = 7;
            // 
            // panelTV
            // 
            this.panelTV.Controls.Add(this.ckbTDT);
            this.panelTV.Controls.Add(this.label10);
            this.panelTV.Controls.Add(this.label9);
            this.panelTV.Controls.Add(this.txbHD);
            this.panelTV.Controls.Add(this.label8);
            this.panelTV.Controls.Add(this.txbResolTV);
            this.panelTV.Controls.Add(this.label7);
            this.panelTV.Controls.Add(this.txbPantallaTV);
            this.panelTV.Controls.Add(this.label6);
            this.panelTV.Controls.Add(this.txbPanel);
            this.panelTV.Location = new System.Drawing.Point(6, 352);
            this.panelTV.Name = "panelTV";
            this.panelTV.Size = new System.Drawing.Size(454, 221);
            this.panelTV.TabIndex = 35;
            this.panelTV.Visible = false;
            // 
            // ckbTDT
            // 
            this.ckbTDT.AutoSize = true;
            this.ckbTDT.Enabled = false;
            this.ckbTDT.Location = new System.Drawing.Point(163, 185);
            this.ckbTDT.Name = "ckbTDT";
            this.ckbTDT.Size = new System.Drawing.Size(18, 17);
            this.ckbTDT.TabIndex = 42;
            this.ckbTDT.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(104, 182);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 20);
            this.label10.TabIndex = 41;
            this.label10.Text = "TDT";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(6, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(140, 20);
            this.label9.TabIndex = 40;
            this.label9.Text = "HDReady/FullHD";
            // 
            // txbHD
            // 
            this.txbHD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbHD.Enabled = false;
            this.txbHD.Location = new System.Drawing.Point(163, 142);
            this.txbHD.MaxLength = 35;
            this.txbHD.Name = "txbHD";
            this.txbHD.Size = new System.Drawing.Size(274, 24);
            this.txbHD.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(54, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 20);
            this.label8.TabIndex = 38;
            this.label8.Text = "Resolución";
            // 
            // txbResolTV
            // 
            this.txbResolTV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbResolTV.Enabled = false;
            this.txbResolTV.Location = new System.Drawing.Point(163, 102);
            this.txbResolTV.MaxLength = 35;
            this.txbResolTV.Name = "txbResolTV";
            this.txbResolTV.Size = new System.Drawing.Size(274, 24);
            this.txbResolTV.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(77, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 20);
            this.label7.TabIndex = 36;
            this.label7.Text = "Pantalla";
            // 
            // txbPantallaTV
            // 
            this.txbPantallaTV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbPantallaTV.Enabled = false;
            this.txbPantallaTV.Location = new System.Drawing.Point(163, 60);
            this.txbPantallaTV.MaxLength = 35;
            this.txbPantallaTV.Name = "txbPantallaTV";
            this.txbPantallaTV.Size = new System.Drawing.Size(274, 24);
            this.txbPantallaTV.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(95, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 34;
            this.label6.Text = "Panel";
            // 
            // txbPanel
            // 
            this.txbPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbPanel.Enabled = false;
            this.txbPanel.Location = new System.Drawing.Point(163, 19);
            this.txbPanel.MaxLength = 35;
            this.txbPanel.Name = "txbPanel";
            this.txbPanel.Size = new System.Drawing.Size(274, 24);
            this.txbPanel.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(28, 331);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 20);
            this.label4.TabIndex = 31;
            this.label4.Text = "Tipo de artículo";
            // 
            // panelObjetivo
            // 
            this.panelObjetivo.Controls.Add(this.label11);
            this.panelObjetivo.Controls.Add(this.txbEspeciales);
            this.panelObjetivo.Controls.Add(this.label15);
            this.panelObjetivo.Controls.Add(this.txbApertura);
            this.panelObjetivo.Controls.Add(this.label16);
            this.panelObjetivo.Controls.Add(this.txbFocal);
            this.panelObjetivo.Controls.Add(this.label17);
            this.panelObjetivo.Controls.Add(this.txbMontura);
            this.panelObjetivo.Controls.Add(this.label18);
            this.panelObjetivo.Controls.Add(this.txbTipoObj);
            this.panelObjetivo.Location = new System.Drawing.Point(6, 354);
            this.panelObjetivo.Name = "panelObjetivo";
            this.panelObjetivo.Size = new System.Drawing.Size(454, 221);
            this.panelObjetivo.TabIndex = 43;
            this.panelObjetivo.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(55, 182);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 20);
            this.label11.TabIndex = 42;
            this.label11.Text = "Especiales";
            // 
            // txbEspeciales
            // 
            this.txbEspeciales.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbEspeciales.Enabled = false;
            this.txbEspeciales.Location = new System.Drawing.Point(162, 181);
            this.txbEspeciales.MaxLength = 35;
            this.txbEspeciales.Name = "txbEspeciales";
            this.txbEspeciales.Size = new System.Drawing.Size(274, 24);
            this.txbEspeciales.TabIndex = 41;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(73, 143);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 20);
            this.label15.TabIndex = 40;
            this.label15.Text = "Apertura";
            // 
            // txbApertura
            // 
            this.txbApertura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbApertura.Enabled = false;
            this.txbApertura.Location = new System.Drawing.Point(163, 142);
            this.txbApertura.MaxLength = 35;
            this.txbApertura.Name = "txbApertura";
            this.txbApertura.Size = new System.Drawing.Size(274, 24);
            this.txbApertura.TabIndex = 39;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(96, 103);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 20);
            this.label16.TabIndex = 38;
            this.label16.Text = "Focal";
            // 
            // txbFocal
            // 
            this.txbFocal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbFocal.Enabled = false;
            this.txbFocal.Location = new System.Drawing.Point(163, 102);
            this.txbFocal.MaxLength = 35;
            this.txbFocal.Name = "txbFocal";
            this.txbFocal.Size = new System.Drawing.Size(274, 24);
            this.txbFocal.TabIndex = 37;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(76, 61);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 20);
            this.label17.TabIndex = 36;
            this.label17.Text = "Montura";
            // 
            // txbMontura
            // 
            this.txbMontura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbMontura.Enabled = false;
            this.txbMontura.Location = new System.Drawing.Point(163, 60);
            this.txbMontura.MaxLength = 35;
            this.txbMontura.Name = "txbMontura";
            this.txbMontura.Size = new System.Drawing.Size(274, 24);
            this.txbMontura.TabIndex = 35;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(105, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 20);
            this.label18.TabIndex = 34;
            this.label18.Text = "Tipo";
            // 
            // txbTipoObj
            // 
            this.txbTipoObj.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbTipoObj.Enabled = false;
            this.txbTipoObj.Location = new System.Drawing.Point(162, 18);
            this.txbTipoObj.MaxLength = 35;
            this.txbTipoObj.Name = "txbTipoObj";
            this.txbTipoObj.Size = new System.Drawing.Size(274, 24);
            this.txbTipoObj.TabIndex = 33;
            // 
            // txbEspec
            // 
            this.txbEspec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbEspec.Enabled = false;
            this.txbEspec.Location = new System.Drawing.Point(169, 161);
            this.txbEspec.MaxLength = 500;
            this.txbEspec.Multiline = true;
            this.txbEspec.Name = "txbEspec";
            this.txbEspec.Size = new System.Drawing.Size(274, 153);
            this.txbEspec.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(16, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Especificaciones";
            // 
            // cbMarca
            // 
            this.cbMarca.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbMarca.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMarca.Enabled = false;
            this.cbMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.ItemHeight = 18;
            this.cbMarca.Location = new System.Drawing.Point(169, 117);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(274, 26);
            this.cbMarca.TabIndex = 5;
            // 
            // nudPvp
            // 
            this.nudPvp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nudPvp.Cursor = System.Windows.Forms.Cursors.Default;
            this.nudPvp.Location = new System.Drawing.Point(169, 77);
            this.nudPvp.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudPvp.Name = "nudPvp";
            this.nudPvp.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.nudPvp.Size = new System.Drawing.Size(274, 24);
            this.nudPvp.TabIndex = 3;
            this.nudPvp.ThousandsSeparator = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(96, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 20);
            this.label12.TabIndex = 29;
            this.label12.Text = "Marca";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(84, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Nombre";
            // 
            // txbNombre
            // 
            this.txbNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txbNombre.Enabled = false;
            this.txbNombre.Location = new System.Drawing.Point(169, 36);
            this.txbNombre.MaxLength = 50;
            this.txbNombre.Name = "txbNombre";
            this.txbNombre.Size = new System.Drawing.Size(274, 24);
            this.txbNombre.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(95, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Precio";
            // 
            // btnMod
            // 
            this.btnMod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(31)))), ((int)(((byte)(51)))));
            this.btnMod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMod.Location = new System.Drawing.Point(919, 701);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(145, 50);
            this.btnMod.TabIndex = 32;
            this.btnMod.Text = "MODIFICAR";
            this.btnMod.UseVisualStyleBackColor = false;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // Productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(11)))), ((int)(((byte)(15)))));
            this.ClientSize = new System.Drawing.Size(1254, 778);
            this.Controls.Add(this.btnMod);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Productos";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Productos";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panelCamara.ResumeLayout(false);
            this.panelCamara.PerformLayout();
            this.panelMemoria.ResumeLayout(false);
            this.panelMemoria.PerformLayout();
            this.panelTV.ResumeLayout(false);
            this.panelTV.PerformLayout();
            this.panelObjetivo.ResumeLayout(false);
            this.panelObjetivo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPvp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txbNomB;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudPvp;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.TextBox txbEspec;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbTipo;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.ComboBox cbTipoB;
        private System.Windows.Forms.Panel panelMemoria;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbTipoMem;
        private System.Windows.Forms.Panel panelTV;
        private System.Windows.Forms.CheckBox ckbTDT;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txbHD;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txbResolTV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txbPantallaTV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txbPanel;
        private System.Windows.Forms.Panel panelObjetivo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txbApertura;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txbFocal;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txbMontura;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txbTipoObj;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txbEspeciales;
        private System.Windows.Forms.Panel panelCamara;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txbObjetivo;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txbFactor;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txbTipoCam;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txbSensor;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txbResolCam;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txbPantallaCam;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txbZoom;
        private System.Windows.Forms.Button btnResetFilters;
    }
}